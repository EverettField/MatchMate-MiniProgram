package com.team.util;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class MatchUtil {
    // 计算匹配度：用户技能 与 需求技能 的交集个数 / 需求技能个数 * 100
    public static int calculateMatchRate(String userSkillsStr, String requiredSkillsStr) {
        if (requiredSkillsStr == null || requiredSkillsStr.isEmpty()) return 0;
        Set<String> userSet = new HashSet<>();
        if (userSkillsStr != null && !userSkillsStr.isEmpty()) {
            userSet.addAll(Arrays.asList(userSkillsStr.split(",")));
        }
        List<String> requiredList = Arrays.asList(requiredSkillsStr.split(","));
        long matchCount = requiredList.stream().filter(userSet::contains).count();
        return (int) (matchCount * 100 / requiredList.size());
    }
}//这部分我来重新写