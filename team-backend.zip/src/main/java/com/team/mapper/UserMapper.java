package com.team.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.team.entity.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper extends BaseMapper<User> {
    // 继承BaseMapper后，基础CRUD方法都有了，不用写SQL
}