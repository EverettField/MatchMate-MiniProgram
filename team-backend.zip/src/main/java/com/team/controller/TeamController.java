package com.team.controller;

import com.team.common.Result;
import com.team.entity.Team;
import com.team.service.TeamService;
import com.team.util.JwtUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/team")
public class TeamController {

    @Autowired
    private TeamService teamService;

    // 发布组队
    @PostMapping("/create")
    public Result<Map<String, Long>> createTeam(
            @RequestHeader("Authorization") String authHeader,
            @RequestBody Team team) {
        // 验证登录
        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return Result.error(401, "未登录");
        }
        String token = authHeader.substring(7);
        Long userId = JwtUtil.getUserIdFromToken(token);
        if (userId == null) {
            return Result.error(401, "token无效");
        }
        team.setUserId(userId);
        Long teamId = teamService.createTeam(team);
        Map<String, Long> data = new HashMap<>();
        data.put("teamId", teamId);
        return Result.success(data);
    }

    // 推荐列表
    @GetMapping("/recommend")
    public Result<List<Map<String, Object>>> recommend(
            @RequestHeader(value = "Authorization", required = false) String authHeader) {
        Long userId = null;
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            userId = JwtUtil.getUserIdFromToken(token);
        }
        List<Map<String, Object>> list = teamService.getRecommendList(userId);
        return Result.success(list);
    }

    // 组队详情
    @GetMapping("/detail")
    public Result<Team> detail(@RequestParam("teamId") Long teamId) {
        Team team = teamService.getTeamDetail(teamId);
        if (team == null) {
            return Result.error(404, "组队不存在");
        }
        return Result.success(team);
    }
}
