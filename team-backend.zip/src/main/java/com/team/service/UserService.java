package com.team.service;

import java.util.List;
import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.team.entity.User;
import com.team.mapper.UserMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {
    @Autowired
    private UserMapper userMapper;

    // 根据openid查找或创建用户
    public User findOrCreate(String openid) {
        LambdaQueryWrapper<User> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(User::getOpenid, openid);
        User user = userMapper.selectOne(wrapper);
        if (user == null) {
            user = new User();
            user.setOpenid(openid);
            user.setNickname("新用户");
            user.setProfileCompleted(false);
            userMapper.insert(user);
        }
        return user;
    }

    public void updateProfile(Long userId, String nickname, String grade, String major, List<String> skillsList) {
        User user = userMapper.selectById(userId);
        if (user != null) {
            user.setNickname(nickname);
            user.setGrade(grade);
            user.setMajor(major);
            // 将技能列表转为逗号分隔字符串
            if (skillsList != null && !skillsList.isEmpty()) {
                user.setSkills(String.join(",", skillsList));
            }
            user.setProfileCompleted(true);
            userMapper.updateById(user);
        }
    }

    public User getById(Long userId) {
        return userMapper.selectById(userId);
    }
}