package com.team.service;

import com.baomidou.mybatisplus.core.conditions.query.LambdaQueryWrapper;
import com.team.entity.Team;
import com.team.entity.User;
import com.team.mapper.TeamMapper;
import com.team.util.MatchUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class TeamService {
    @Autowired
    private TeamMapper teamMapper;
    @Autowired
    private UserService userService;

    public Long createTeam(Team team) {
        team.setStatus("active");
        team.setCurrentCount(1);
        team.setCreateTime(new Date().toInstant().atZone(java.time.ZoneId.systemDefault()).toLocalDateTime());
        teamMapper.insert(team);
        return team.getId();
    }

    public List<Map<String, Object>> getRecommendList(Long currentUserId) {
        // 获取当前用户的技能
        User currentUser = userService.getById(currentUserId);
        String userSkills = (currentUser != null) ? currentUser.getSkills() : "";
        // 获取所有 active 状态的组队
        LambdaQueryWrapper<Team> wrapper = new LambdaQueryWrapper<>();
        wrapper.eq(Team::getStatus, "active");
        List<Team> teams = teamMapper.selectList(wrapper);
        // 为每个团队计算匹配度并包装返回数据
        List<Map<String, Object>> result = new ArrayList<>();
        for (Team team : teams) {
            int matchRate = MatchUtil.calculateMatchRate(userSkills, team.getRequiredSkills());
            User publisher = userService.getById(team.getUserId());
            Map<String, Object> item = new HashMap<>();
            item.put("id", team.getId());
            item.put("title", team.getTitle());
            item.put("description", team.getDescription());
            item.put("requiredSkills", Arrays.asList(team.getRequiredSkills().split(",")));
            item.put("neededCount", team.getNeededCount());
            item.put("currentCount", team.getCurrentCount());
            item.put("matchRate", matchRate);
            if (publisher != null) {
                Map<String, Object> userMap = new HashMap<>();
                userMap.put("nickname", publisher.getNickname());
                userMap.put("avatar", publisher.getAvatar());
                userMap.put("grade", publisher.getGrade());
                userMap.put("major", publisher.getMajor());
                item.put("user", userMap);
            }
            item.put("createTime", team.getCreateTime());
            result.add(item);
        }
        // 按匹配度降序排序
        result.sort((a, b) -> Integer.compare((int)b.get("matchRate"), (int)a.get("matchRate")));
        return result;
    }

    public Team getTeamDetail(Long teamId) {
        return teamMapper.selectById(teamId);
    }
}